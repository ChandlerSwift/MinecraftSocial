<?php
unlink('install.php');
unlink('MinecraftSocial.sql');
unlink('removefiles.php');
