<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Registration Success | <?php include_once "includes/config.php"; echo $sitename; ?></title>
        <link rel="stylesheet" href="css/bootstrap.min.css" />
    </head>
    <body>
        <h1 style="text-align:center;">Registration successful!</h1>
        <p style="text-align:center;">You can now go back to the <a href="login.php">login page</a> and log in.</p>
    </body>
</html>
